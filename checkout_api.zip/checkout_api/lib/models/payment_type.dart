enum PaymentMethod { ApplePay, Card, GooglePay }
enum PaymentSourceType { Id, Token }
